Page({
  data: {
    statusMsg: "系统静默待命中",
    randomSource: "",
    isComputing: false,
    radius: 3000 // 探测半径：3000米
  },

  // 1. 触发入口：获取位置
  startCollapse() {
    this.setData({ 
      isComputing: true,
      statusMsg: "提取物理空间锚点...",
      randomSource: "等待数据源响应"
    });

    wx.getLocation({
      type: 'gcj02',
      isHighAccuracy: true,
      success: (res) => {
        const currentLat = res.latitude;
        const currentLon = res.longitude;
        this.setData({ statusMsg: "锚点锁定。正在连接量子真空接口..." });
        // 发起量子API请求
        this.fetchQuantumData(currentLat, currentLon);
      },
      fail: (err) => {
        this.setData({
          isComputing: false,
          statusMsg: "权限拒绝：无法突破当前网格。",
          randomSource: "连接失败"
        });
      }
    });
  },

  // 2. 核心网络逻辑：选择随机来源
  fetchQuantumData(lat, lon) {
    // 设置 3 秒超时，以防网络卡死影响体验
    wx.request({
      url: 'https://qrng.anu.edu.au/API/jsonI.php?length=2&type=uint16',
      method: 'GET',
      timeout: 3000, 
      success: (res) => {
        if (res.data && res.data.success) {
          // 成功连接澳大利亚量子实验室
          const u = res.data.data[0] / 65536.0;
          const v = res.data.data[1] / 65536.0;
          this.calculateAndNavigate(lat, lon, u, v, "ANU 实验室 (真空涨落TRNG)");
        } else {
          this.fallbackToLocal(lat, lon);
        }
      },
      fail: () => {
        // 请求失败、超时、或被长城防火墙拦截，触发自动降级
        this.fallbackToLocal(lat, lon);
      }
    });
  },

  // 降级方案：本地高熵伪随机
  fallbackToLocal(lat, lon) {
    this.setData({ statusMsg: "网络阻断。已自动切入本地高熵池..." });
    // 利用当前高精度时间戳（毫秒）注入底层的 Math.random
    const entropy = Date.now() % 1000 / 1000;
    const u = (Math.random() + entropy) % 1.0;
    const v = Math.random();
    
    // 给 UI 一点表现动画的时间
    setTimeout(() => {
      this.calculateAndNavigate(lat, lon, u, v, "本地芯片组 (高熵CSPRNG)");
    }, 800);
  },

  // 3. 数学坍缩与地图唤醒
  calculateAndNavigate(startLat, startLon, u, v, sourceName) {
    this.setData({ randomSource: sourceName });

    // 面积均匀极坐标转换
    const radiusMeters = this.data.radius;
    const radiusOffset = radiusMeters * Math.sqrt(u);
    const theta = 2 * Math.PI * v;

    // 转换为笛卡尔经纬度偏移
    const deltaLat = (radiusOffset * Math.cos(theta)) / 111320.0;
    const deltaLon = (radiusOffset * Math.sin(theta)) / (111320.0 * Math.cos(startLat * Math.PI / 180));

    const targetLat = startLat + deltaLat;
    const targetLon = startLon + deltaLon;

    this.setData({
      statusMsg: "坐标坍缩完毕。正在唤醒导航矩阵...",
      isComputing: false
    });

    // 延迟500ms打开地图，让用户看清状态变更
    setTimeout(() => {
      wx.openLocation({
        latitude: targetLat,
        longitude: targetLon,
        scale: 16,
        name: "观测异常点",
        address: `此坐标由 [${sourceName}] 决定`
      });
      // 恢复系统默认状态
      this.setData({ statusMsg: "系统静默待命中", randomSource: "" });
    }, 1500);
  }
});